# 旧品牌名称扫描（自动生成）

命令：`npm run audit:brand` · 2026-10-20T08:34:38.106Z

扫描范围：src/studio、src/brand、src/app/main.tsx、index.html、chat.html、tools/legacy-export.js，以及构建后的 dist/index.html、manifest。

共 84 处，已审阅保留 84 处，未通过 0 处；构建产物入口/清单中的旧名：无。

| 文件:行 | 内容 | 结论 |
|---|---|---|
| `src/studio/ai/openaiCompat.ts:2` | * OpenAI-compatible provider — a thin adapter over the UPSTREAM InkFlow client | 保留：代码注释：说明复用上游 InkFlow 客户端 |
| `src/studio/ai/provider.ts:5` | *  - "openai-compatible": reuses the upstream InkFlow client (ChatGPTApi + | 保留：代码注释：说明复用上游 InkFlow 客户端（署名） |
| `src/studio/data/backup.ts:4` | * Format: { format: "novellure.project", schemaVersion, generator, project, | 保留：技术标识：备份文件格式名（改名会让旧备份无法导入） |
| `src/studio/data/backup.ts:30` | export const PROJECT_FORMAT = "novellure.project"; | 保留：技术标识：备份文件格式名（改名会让旧备份无法导入） |
| `src/studio/data/backup.ts:31` | export const LIBRARY_FORMAT = "novellure.library"; | 保留：技术标识：备份文件格式名（改名会让旧备份无法导入） |
| `src/studio/data/backup.ts:438` | \| { kind: "eraproof"; data: unknown } | 保留：旧数据格式识别（代码内部标识） |
| `src/studio/data/backup.ts:446` | if (d.version === 1 && Array.isArray(d.entries) && "projectId" in d) return { kind: "eraproof", data }; | 保留：旧数据格式识别（代码内部标识） |
| `src/studio/data/db.ts:2` | * IndexedDB schema for the Writing Studio (database "novellure-studio" — | 保留：技术标识：IndexedDB 数据库名与类型名（改名会丢数据）；注释说明上游数据库互不影响 |
| `src/studio/data/db.ts:6` | * edit an earlier block. The upstream InkFlow data lives in a different | 保留：技术标识：IndexedDB 数据库名与类型名（改名会丢数据）；注释说明上游数据库互不影响 |
| `src/studio/data/db.ts:7` | * database (idb-keyval "keyval-store", keys `inkflow-*`) and is never touched. | 保留：技术标识：IndexedDB 数据库名与类型名（改名会丢数据）；注释说明上游数据库互不影响 |
| `src/studio/data/db.ts:25` | export const DB_NAME = "novellure-studio"; | 保留：技术标识：IndexedDB 数据库名与类型名（改名会丢数据）；注释说明上游数据库互不影响 |
| `src/studio/data/db.ts:28` | export interface NovellureDB extends DBSchema { | 保留：技术标识：IndexedDB 数据库名与类型名（改名会丢数据）；注释说明上游数据库互不影响 |
| `src/studio/data/db.ts:70` | let dbPromise: Promise<IDBPDatabase<NovellureDB>> \| null = null; | 保留：技术标识：IndexedDB 数据库名与类型名（改名会丢数据）；注释说明上游数据库互不影响 |
| `src/studio/data/db.ts:72` | export function getDB(): Promise<IDBPDatabase<NovellureDB>> { | 保留：技术标识：IndexedDB 数据库名与类型名（改名会丢数据）；注释说明上游数据库互不影响 |
| `src/studio/data/db.ts:74` | dbPromise = openDB<NovellureDB>(DB_NAME, DB_VERSION, { | 保留：技术标识：IndexedDB 数据库名与类型名（改名会丢数据）；注释说明上游数据库互不影响 |
| `src/studio/data/legacy.ts:2` | * Legacy data migration (versioned): InkFlow knowledge + EraProof ledger cards | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:3` | * → NOVELLURE projects. | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:11` | import { getDB as getNovellureDB } from "./db"; | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:19` | export const MIGRATION_ID = "legacy-inkflow-eraproof-v1"; | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:22` | // Upstream InkFlow persists via idb-keyval (db "keyval-store", store "keyval") | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:27` | export interface LegacyEraProofEntry { | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:52` | inkflowProjects: { id: string; name: string }[]; | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:54` | eraproof: { projectId: string; entries: LegacyEraProofEntry[] }[]; | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:140` | export function parseEraProofEntries(value: unknown): LegacyEraProofEntry[] { | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:143` | (v): v is LegacyEraProofEntry => | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:169` | const inkflowProjects = Array.isArray(projState?.projects) | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:180` | const eraproof: LegacyScan["eraproof"] = []; | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:189` | const entries = parseEraProofEntries(parsed); | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:190` | if (entries.length) eraproof.push({ projectId: key.slice(brand.legacy.eraProofStoragePrefix.length), entries }); | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:194` | found: eraproof.length > 0 \|\| migratableKnowledge.length > 0, | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:195` | inkflowProjects, | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:197` | eraproof, | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:207` | export const LEGACY_BUNDLE_FORMAT = "inkflow-eraproof.legacy-export"; | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:232` | const TYPE_MAP: Record<LegacyEraProofEntry["kind"], LedgerType> = { | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:239` | /** Map one EraProof card. Conservative: "作者已核对" → reviewed (not confirmed). */ | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:240` | export function mapEraProofEntry(e: LegacyEraProofEntry, projectId: string, now = Date.now()): LedgerEntry { | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:273` | ledger: LegacyEraProofEntry[]; | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:277` | const ids = new Set<string>([...scan.eraproof.map((g) => g.projectId), ...scan.knowledge.map((k) => k.projectId!)]); | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:280` | const name = scan.inkflowProjects.find((p) => p.id === legacyId)?.name; | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:298` | ledger: scan.eraproof.find((g) => g.projectId === legacyId)?.entries ?? [], | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:341` | const ledger = p.ledger.map((e) => mapEraProofEntry(e, project.id)); | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:365` | const db = await getNovellureDB(); | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:414` | const db = await getNovellureDB(); | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:426` | /** Entries from an EraProof JSON export file ({version:1, projectId, entries}). */ | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:427` | export function eraProofFileEntries(data: unknown): LegacyEraProofEntry[] { | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:431` | return parseEraProofEntries(d.entries).slice(0, 5000); | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:434` | /** Add EraProof cards to an existing project (skips claims already present). */ | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:435` | export async function importEraProofIntoProject( | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:437` | entries: LegacyEraProofEntry[], | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:439` | const db = await getNovellureDB(); | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/legacy.ts:443` | const mapped = fresh.map((e) => mapEraProofEntry(e, projectId)); | 保留：旧数据迁移：读取 InkFlow / EraProof 的原有存储键与格式 |
| `src/studio/data/repo.ts:8` | import { getDB, PROJECT_SCOPED_STORES, type NovellureDB, type ProjectScopedStore } from "./db"; | 保留：技术标识：数据库类型名（代码内部） |
| `src/studio/data/repo.ts:878` | type RestoreTx = IDBPTransaction<NovellureDB, ("projects" \| "trash" \| ProjectScopedStore)[], "readwrite">; | 保留：技术标识：数据库类型名（代码内部） |
| `src/studio/model/numbers.ts:5` | * The upstream InkFlow `chineseToNumber` (src/utils/chinese.ts) only handles | 保留：代码注释：与上游实现的差异 |
| `src/studio/model/types.ts:237` | /** Upstream InkFlow slop score of the result, if computed. */ | 保留：代码注释：文风评分来自上游 InkFlow（署名） |
| `src/studio/store/prefs.ts:28` | const KEY = "novellure:prefs:v1"; | 保留：技术标识：本机偏好存储键 |
| `src/studio/ui/AiPanel.tsx:303` | <span className="muted">（InkFlow 规则）</span> | 保留：署名：文风检测规则来自 InkFlow |
| `src/studio/ui/SettingsDialog.tsx:269` | 浏览器按网址隔离数据，新网址无法读取旧网址保存的内容。若旧版 InkFlow / EraProof 在别的网址使用，请在旧网址运行 <code>tools/legacy-export.js</code> 导出文件，或使用旧版账本的「导出备份」按钮，然后在这里导入。 | 保留：关于页署名 / 旧版数据迁移说明 |
| `src/studio/ui/SettingsDialog.tsx:274` | 在本网址发现旧数据：{scan.eraproof.reduce((s, g) => s + g.entries.length, 0)} 条旧版账本记录、{scan.knowledge.length} 条项目设定。 | 保留：旧数据扫描结果字段（代码内部标识） |
| `src/studio/ui/transfer.ts:3` | import { eraProofFileEntries, importEraProofIntoProject, importLegacyBundle, LEGACY_BUNDLE_FORMAT } from "../data/legacy"; | 保留：旧版账本文件导入（代码内部标识与注释） |
| `src/studio/ui/transfer.ts:71` | * EraProof file) or a TXT/Markdown manuscript as a new novel. | 保留：旧版账本文件导入（代码内部标识与注释） |
| `src/studio/ui/transfer.ts:106` | if (kind.kind === "eraproof") { | 保留：旧版账本文件导入（代码内部标识与注释） |
| `src/studio/ui/transfer.ts:123` | const r = await importEraProofIntoProject(target, entries); | 保留：旧版账本文件导入（代码内部标识与注释） |
| `src/brand/brand.ts:12` | * "novellure-studio", the prefs key "novellure:prefs:v1", the git branch | 保留：品牌配置：备选品牌档案 novellure、遗留代号与上游署名（不直接显示） |
| `src/brand/brand.ts:13` | * "novellure/studio", and the upstream InkFlow storage keys `inkflow-*`. | 保留：品牌配置：备选品牌档案 novellure、遗留代号与上游署名（不直接显示） |
| `src/brand/brand.ts:51` | novellure: { | 保留：品牌配置：备选品牌档案 novellure、遗留代号与上游署名（不直接显示） |
| `src/brand/brand.ts:52` | canonicalName: "NOVELLURE", | 保留：品牌配置：备选品牌档案 novellure、遗留代号与上游署名（不直接显示） |
| `src/brand/brand.ts:53` | zhName: "叙鉴", | 保留：品牌配置：备选品牌档案 novellure、遗留代号与上游署名（不直接显示） |
| `src/brand/brand.ts:54` | fullName: "NOVELLURE · 叙鉴", | 保留：品牌配置：备选品牌档案 novellure、遗留代号与上游署名（不直接显示） |
| `src/brand/brand.ts:55` | appShortName: "NOVELLURE", | 保留：品牌配置：备选品牌档案 novellure、遗留代号与上游署名（不直接显示） |
| `src/brand/brand.ts:68` | nameRiskNote: "NOVELLURE 为早期候选名（已非首选），未完成商标与域名检索。", | 保留：品牌配置：备选品牌档案 novellure、遗留代号与上游署名（不直接显示） |
| `src/brand/brand.ts:98` | eraProofCodename: "EraProof", | 保留：品牌配置：备选品牌档案 novellure、遗留代号与上游署名（不直接显示） |
| `src/brand/brand.ts:99` | novellureCodename: "NOVELLURE", | 保留：品牌配置：备选品牌档案 novellure、遗留代号与上游署名（不直接显示） |
| `src/brand/brand.ts:101` | upstreamName: "InkFlow", | 保留：品牌配置：备选品牌档案 novellure、遗留代号与上游署名（不直接显示） |
| `src/brand/brand.ts:102` | upstreamRepo: "https://github.com/Boundless-Fang/InkFlow", | 保留：品牌配置：备选品牌档案 novellure、遗留代号与上游署名（不直接显示） |
| `src/brand/brand.ts:106` | upstreamStoragePrefix: "inkflow-", | 保留：品牌配置：备选品牌档案 novellure、遗留代号与上游署名（不直接显示） |
| `src/brand/brand.ts:107` | eraProofStoragePrefix: "eraproof:evidence:v1:", | 保留：品牌配置：备选品牌档案 novellure、遗留代号与上游署名（不直接显示） |
| `src/app/main.tsx:9` | // Classic chat mode (upstream InkFlow UI). A slim bar links back to the Writing Studio. | 保留：经典对话：注明源自 InkFlow（署名） |
| `src/app/main.tsx:20` | <span style={{ color: "#948C80" }}>AI 对话（经典模式，源自 InkFlow）</span> | 保留：经典对话：注明源自 InkFlow（署名） |
| `tools/legacy-export.js:2` | * Legacy data export tool (InkFlow + EraProof → JSON file) | 保留：旧数据导出工具：在旧网址运行，读取 InkFlow / EraProof 键 |
| `tools/legacy-export.js:5` | * that the old InkFlow/EraProof page saved under a different address. Run this | 保留：旧数据导出工具：在旧网址运行，读取 InkFlow / EraProof 键 |
| `tools/legacy-export.js:14` | * On iPad: use the old EraProof panel's own「导出备份」button instead (one JSON | 保留：旧数据导出工具：在旧网址运行，读取 InkFlow / EraProof 键 |
| `tools/legacy-export.js:19` | format: "inkflow-eraproof.legacy-export", | 保留：旧数据导出工具：在旧网址运行，读取 InkFlow / EraProof 键 |
| `tools/legacy-export.js:26` | const wanted = (k) => k.startsWith("inkflow-") \|\| k.startsWith("eraproof:evidence:v1:"); | 保留：旧数据导出工具：在旧网址运行，读取 InkFlow / EraProof 键 |
