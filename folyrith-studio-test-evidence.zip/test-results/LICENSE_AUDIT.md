# 许可证与来源审计（自动生成）

生成命令：`npm run audit:licenses` · 生成时间：2026-10-20T08:34:37.314Z

> studio: 依据实际构建产物 dist/module-graph.json（只列出真正打包进产物的源文件；纯类型文件不计入）

## 写作工作台（index.html） — 入口 `src/studio/main.tsx`，共 59 个源文件

| 文件 | 来源 | 许可状态 |
|---|---|---|
| `src/services/api/client.ts` | InkFlow upstream + NextChat | InkFlow: README 声明 MIT（无 LICENSE 文件）；NextChat: MIT © 2023-2025 NextChat |
| `src/services/api/providers/openai.ts` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/services/api/stream.ts` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/services/checker/slop-detector.ts` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/services/checker/slop-rules.ts` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/services/storage/database.ts` | InkFlow upstream + NextChat | InkFlow: README 声明 MIT（无 LICENSE 文件）；NextChat: MIT © 2023-2025 NextChat |
| `src/store/settingsStore.ts` | InkFlow upstream + NextChat + StyleSync-Novel | InkFlow: README 声明 MIT（无 LICENSE 文件）；NextChat: MIT © 2023-2025 NextChat；StyleSync-Novel: 未声明许可证（与 InkFlow 同一作者）；人工复核：仅两个设置字段（globalForbidden / forbiddenTolerance）的声明与默认值注明“from StyleSync-Novel”；工作台不使用这两个字段。 |
| `src/types/api.ts` | InkFlow upstream + NextChat + StyleSync-Novel | InkFlow: README 声明 MIT（无 LICENSE 文件）；NextChat: MIT © 2023-2025 NextChat；StyleSync-Novel: 未声明许可证（与 InkFlow 同一作者）；人工复核：StyleSync-Novel 字样只出现在 LLMConfig 类型字段 thinking / reasoning_effort 的注释上（类型在构建时擦除）；进入产物的是服务商枚举、URL 常量和 DEFAULT_MODELS 等 NextChat/InkFlow 代码。 |
| `src/utils/text.ts` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |

汇总：studio (original, this project) 50 个；InkFlow upstream + NextChat 2 个；InkFlow upstream 5 个；InkFlow upstream + NextChat + StyleSync-Novel 2 个

> classicChat: 依据实际构建产物 dist/module-graph.json（只列出真正打包进产物的源文件；纯类型文件不计入）

## 经典对话（chat.html，上游 InkFlow 界面） — 入口 `src/app/main.tsx`，共 42 个源文件

| 文件 | 来源 | 许可状态 |
|---|---|---|
| `src/app/App.tsx` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/app/main.tsx` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/components/chat/ChatHeader.tsx` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/components/chat/ChatMessage.tsx` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/components/chat/ChatView.tsx` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/components/chat/HistorySidebar.tsx` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/components/chat/InputSection.tsx` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/components/common/CheckerBar.tsx` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/components/common/ErrorBoundary.tsx` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/components/common/SearchSheet.tsx` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/components/knowledge/KnowledgeSheet.tsx` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/components/knowledge/OutlineConfigSheet.tsx` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/components/settings/SettingsPanel.tsx` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/hooks/useChat.ts` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/pages/HomePage.tsx` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/services/api/client.ts` | InkFlow upstream + NextChat | InkFlow: README 声明 MIT（无 LICENSE 文件）；NextChat: MIT © 2023-2025 NextChat |
| `src/services/api/controller.ts` | InkFlow upstream + NextChat | InkFlow: README 声明 MIT（无 LICENSE 文件）；NextChat: MIT © 2023-2025 NextChat |
| `src/services/api/providers/openai.ts` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/services/api/stream.ts` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/services/checker/banned.ts` | InkFlow upstream + StyleSync-Novel | InkFlow: README 声明 MIT（无 LICENSE 文件）；StyleSync-Novel: 未声明许可证（与 InkFlow 同一作者） |
| `src/services/checker/duplicate.ts` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/services/checker/index.ts` | InkFlow upstream + StyleSync-Novel | InkFlow: README 声明 MIT（无 LICENSE 文件）；StyleSync-Novel: 未声明许可证（与 InkFlow 同一作者） |
| `src/services/checker/opening.ts` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/services/checker/slop-detector.ts` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/services/checker/slop-rules.ts` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/services/storage/database.ts` | InkFlow upstream + NextChat | InkFlow: README 声明 MIT（无 LICENSE 文件）；NextChat: MIT © 2023-2025 NextChat |
| `src/store/chatStore.ts` | InkFlow upstream + NextChat + StyleSync-Novel | InkFlow: README 声明 MIT（无 LICENSE 文件）；NextChat: MIT © 2023-2025 NextChat；StyleSync-Novel: 未声明许可证（与 InkFlow 同一作者） |
| `src/store/checkerStore.ts` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/store/knowledgeStore.ts` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/store/outlineStore.ts` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/store/projectStore.ts` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/store/promptStore.ts` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/store/settingsStore.ts` | InkFlow upstream + NextChat + StyleSync-Novel | InkFlow: README 声明 MIT（无 LICENSE 文件）；NextChat: MIT © 2023-2025 NextChat；StyleSync-Novel: 未声明许可证（与 InkFlow 同一作者） |
| `src/types/api.ts` | InkFlow upstream + NextChat + StyleSync-Novel | InkFlow: README 声明 MIT（无 LICENSE 文件）；NextChat: MIT © 2023-2025 NextChat；StyleSync-Novel: 未声明许可证（与 InkFlow 同一作者） |
| `src/types/chat.ts` | InkFlow upstream + NextChat + StyleSync-Novel | InkFlow: README 声明 MIT（无 LICENSE 文件）；NextChat: MIT © 2023-2025 NextChat；StyleSync-Novel: 未声明许可证（与 InkFlow 同一作者） |
| `src/types/outline.ts` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/types/prompt.ts` | InkFlow upstream + NextChat | InkFlow: README 声明 MIT（无 LICENSE 文件）；NextChat: MIT © 2023-2025 NextChat |
| `src/utils/id.ts` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/utils/similarity.ts` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/utils/template.ts` | InkFlow upstream + NextChat | InkFlow: README 声明 MIT（无 LICENSE 文件）；NextChat: MIT © 2023-2025 NextChat |
| `src/utils/text.ts` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |
| `src/utils/token.ts` | InkFlow upstream | InkFlow: README 声明 MIT（无 LICENSE 文件） |

汇总：InkFlow upstream 31 个；InkFlow upstream + NextChat 5 个；InkFlow upstream + StyleSync-Novel 2 个；InkFlow upstream + NextChat + StyleSync-Novel 4 个

## npm 生产依赖（133 个，含传递依赖）

按许可证：MIT × 128，BSD-3-Clause × 2，ISC × 1，Apache-2.0 × 1，0BSD × 1

未发现宽松许可证以外的依赖。

<details><summary>完整列表</summary>

| 包 | 版本 | 许可证 |
|---|---|---|
| @capacitor/android | 6.2.1 | MIT |
| @capacitor/core | 6.2.1 | MIT |
| @capacitor/filesystem | 6.0.4 | MIT |
| @capacitor/keyboard | 6.0.4 | MIT |
| @capacitor/splash-screen | 6.0.4 | MIT |
| @capacitor/status-bar | 6.0.3 | MIT |
| @codemirror/commands | 6.7.1 | MIT |
| @codemirror/language | 6.13.1 | MIT |
| @codemirror/search | 6.5.6 | MIT |
| @codemirror/state | 6.4.1 | MIT |
| @codemirror/streamparser | 6.0.0 | MIT |
| @codemirror/view | 6.34.1 | MIT |
| @lezer/common | 1.5.3 | MIT |
| @lezer/highlight | 1.2.5 | MIT |
| @lezer/lr | 1.4.11 | MIT |
| @remix-run/router | 1.23.3 | MIT |
| @types/debug | 4.1.13 | MIT |
| @types/hast | 2.3.10 | MIT |
| @types/mdast | 3.0.15 | MIT |
| @types/ms | 2.1.0 | MIT |
| @types/prop-types | 15.7.15 | MIT |
| @types/react | 18.3.31 | MIT |
| @types/unist | 2.0.11 | MIT |
| bail | 2.0.2 | MIT |
| ccount | 2.0.1 | MIT |
| character-entities | 2.0.2 | MIT |
| comma-separated-tokens | 2.0.3 | MIT |
| crelt | 1.0.7 | MIT |
| csstype | 3.2.3 | MIT |
| debug | 4.4.3 | MIT |
| decode-named-character-reference | 1.3.0 | MIT |
| dequal | 2.0.3 | MIT |
| diff | 5.2.0 | BSD-3-Clause |
| escape-string-regexp | 5.0.0 | MIT |
| extend | 3.0.2 | MIT |
| fault | 2.0.1 | MIT |
| format | 0.2.2 | MIT |
| hast-util-is-element | 2.1.3 | MIT |
| hast-util-to-text | 3.1.2 | MIT |
| hast-util-whitespace | 2.0.1 | MIT |
| highlight.js | 11.8.0 | BSD-3-Clause |
| idb | 8.0.0 | ISC |
| idb-keyval | 6.2.5 | Apache-2.0 |
| inline-style-parser | 0.1.1 | MIT |
| is-buffer | 2.0.5 | MIT |
| is-plain-obj | 4.1.0 | MIT |
| js-tokens | 4.0.0 | MIT |
| kleur | 4.1.5 | MIT |
| longest-streak | 3.1.0 | MIT |
| loose-envify | 1.4.0 | MIT |
| lowlight | 2.9.0 | MIT |
| markdown-table | 3.0.4 | MIT |
| mdast-util-definitions | 5.1.2 | MIT |
| mdast-util-find-and-replace | 2.2.2 | MIT |
| mdast-util-from-markdown | 1.3.1 | MIT |
| mdast-util-gfm | 2.0.2 | MIT |
| mdast-util-gfm-autolink-literal | 1.0.3 | MIT |
| mdast-util-gfm-footnote | 1.0.2 | MIT |
| mdast-util-gfm-strikethrough | 1.0.3 | MIT |
| mdast-util-gfm-table | 1.0.7 | MIT |
| mdast-util-gfm-task-list-item | 1.0.2 | MIT |
| mdast-util-phrasing | 3.0.1 | MIT |
| mdast-util-to-hast | 12.3.0 | MIT |
| mdast-util-to-markdown | 1.5.0 | MIT |
| mdast-util-to-string | 3.2.0 | MIT |
| micromark | 3.2.0 | MIT |
| micromark-core-commonmark | 1.1.0 | MIT |
| micromark-extension-gfm | 2.0.3 | MIT |
| micromark-extension-gfm-autolink-literal | 1.0.5 | MIT |
| micromark-extension-gfm-footnote | 1.1.2 | MIT |
| micromark-extension-gfm-strikethrough | 1.0.7 | MIT |
| micromark-extension-gfm-table | 1.0.7 | MIT |
| micromark-extension-gfm-tagfilter | 1.0.2 | MIT |
| micromark-extension-gfm-task-list-item | 1.0.5 | MIT |
| micromark-factory-destination | 1.1.0 | MIT |
| micromark-factory-label | 1.1.0 | MIT |
| micromark-factory-space | 1.1.0 | MIT |
| micromark-factory-title | 1.1.0 | MIT |
| micromark-factory-whitespace | 1.1.0 | MIT |
| micromark-util-character | 1.2.0 | MIT |
| micromark-util-chunked | 1.1.0 | MIT |
| micromark-util-classify-character | 1.1.0 | MIT |
| micromark-util-combine-extensions | 1.1.0 | MIT |
| micromark-util-decode-numeric-character-reference | 1.1.0 | MIT |
| micromark-util-decode-string | 1.1.0 | MIT |
| micromark-util-encode | 1.1.0 | MIT |
| micromark-util-html-tag-name | 1.2.0 | MIT |
| micromark-util-normalize-identifier | 1.1.0 | MIT |
| micromark-util-resolve-all | 1.1.0 | MIT |
| micromark-util-sanitize-uri | 1.2.0 | MIT |
| micromark-util-subtokenize | 1.1.0 | MIT |
| micromark-util-symbol | 1.1.0 | MIT |
| micromark-util-types | 1.1.0 | MIT |
| mri | 1.2.0 | MIT |
| ms | 2.1.3 | MIT |
| nanoid | 5.1.11 | MIT |
| object-assign | 4.1.1 | MIT |
| prop-types | 15.8.1 | MIT |
| property-information | 6.5.0 | MIT |
| react | 18.3.1 | MIT |
| react-dom | 18.3.1 | MIT |
| react-is | 16.13.1 | MIT |
| react-is | 18.3.1 | MIT |
| react-markdown | 8.0.7 | MIT |
| react-router | 6.30.4 | MIT |
| react-router-dom | 6.30.4 | MIT |
| rehype-highlight | 6.0.0 | MIT |
| remark-gfm | 3.0.1 | MIT |
| remark-parse | 10.0.2 | MIT |
| remark-rehype | 10.1.0 | MIT |
| sade | 1.8.1 | MIT |
| scheduler | 0.23.2 | MIT |
| space-separated-tokens | 2.0.2 | MIT |
| style-mod | 4.1.4 | MIT |
| style-to-object | 0.4.4 | MIT |
| trim-lines | 3.0.1 | MIT |
| trough | 2.2.0 | MIT |
| tslib | 2.8.1 | 0BSD |
| unified | 10.1.2 | MIT |
| unist-util-find-after | 4.0.1 | MIT |
| unist-util-generated | 2.0.1 | MIT |
| unist-util-is | 5.2.1 | MIT |
| unist-util-position | 4.0.4 | MIT |
| unist-util-stringify-position | 3.0.3 | MIT |
| unist-util-visit | 4.1.2 | MIT |
| unist-util-visit-parents | 5.1.3 | MIT |
| use-sync-external-store | 1.6.0 | MIT |
| uvu | 0.5.6 | MIT |
| vfile | 5.3.7 | MIT |
| vfile-message | 3.1.4 | MIT |
| w3c-keyname | 2.2.8 | MIT |
| zustand | 4.5.7 | MIT |
| zwitch | 2.0.4 | MIT |

</details>
